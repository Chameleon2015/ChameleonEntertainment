import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs, shutil, urllib2, urllib, plugintools, time, downloader, extract, re
from addon.common.addon import Addon
from addon.common.net import Net

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'; ADDON_ID = 'plugin.program.chameleonbuilds'
VERSION = "1.0.10"; ADDON = xbmcaddon.Addon(id=ADDON_ID); HOME = ADDON.getAddonInfo('path'); PATH = "Chameleon Builds"
Decode = base64.decodestring; FANART = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png')); BASEURL = Decode('aHR0cDovL2NoYW1lbGVvbi54MTBob3N0LmNvbS9CdWlsZHM=')
ART = Decode('aHR0cDovL2NoYW1lbGVvbi54MTBob3N0LmNvbS9BUlQv'); zip = ADDON.getSetting('zip'); dialog = xbmcgui.Dialog(); dp = xbmcgui.DialogProgress()
#-------------------------------------------------------

def INDEX():
	eval(Decode("YWRkRGlyKCdGYW1pbHkgQnVpbGQgVjEuNScsJycsMixBUlQrJ2ZhbWlseS5wbmcnLEZBTkFSVCwnJyk=")); eval(Decode("YWRkRGlyKCdTdXBlciBMaWdodCA4OE1CJywnJywzLEFSVCsnU3VwZXJMaWdodC5wbmcnLEZBTkFSVCwnJyk=")); eval(Decode("YWRkRGlyKCdLaWRzIEJ1aWxkJywnJyw2LEFSVCsnS2lkc0J1aWxkLnBuZycsRkFOQVJULCcnKQ==")); eval(Decode("YWRkTGluaygnUGVyc29uYWwgQnVpbGQnLCcnLDE2LEFSVCsnUGVyc29uYWxCdWlsZC5wbmcnLEZBTkFSVCk=")); eval(Decode("QVVUT19WSUVXKCc1MDAnKQ=="))
	
#-------------------------------------------------------

def FAMILY():
	addDir('Link 1 - DropBox',Decode('aHR0cHM6Ly93d3cuZHJvcGJveC5jb20vcy9hbTQxZjNkZ3plN3BiMWwvQ2hhbWVsZW9uLVYxLjUuemlwP2RsPTE='),10,ART+'L1DropBox.png',FANART,'')
	#addDir('Link 2 - X10Host',Decode('aHR0cDovL2NoYW1lbGVvbi54MTBob3N0LmNvbS9CdWlsZHMvQ2hhbWVsZW9uVjEuMy56aXA='),10,ART+'L2X10Host.png',FANART,'')
	addDir('Link 2 - Archive.org',Decode('aHR0cHM6Ly9hcmNoaXZlLm9yZy9kb3dubG9hZC9DaGFtZWxlb25WMS41L0NoYW1lbGVvbi1WMS41LnppcA=='),10,ART+'L3Archive.png',FANART,'')
	addDir('Build Fixes','',4,ART+'BuildFixes.png',FANART,'')
	AUTO_VIEW('500')

#-------------------------

def FamBuildFixes():
	addDir('Stalker Fix',Decode('aHR0cHM6Ly9hcmNoaXZlLm9yZy9kb3dubG9hZC9TdGFsa2VyRml4XzIwMTUxMC9TdGFsa2VyRml4LnppcA=='),10,ART+'StalkerFix.png',FANART,'')
	AUTO_VIEW('500')

#-------------------------
def personal_Builds():
	dialog = xbmcgui.Dialog()
	downloadCode = dialog.input('Download Code', type=xbmcgui.INPUT_NUMERIC)
	if downloadCode != '':
		find_Build = open_URL(Decode('aHR0cDovL2NoYW1lbGVvbi54MTBob3N0LmNvbS9BZGRvbl9GaWxlcy9DaGFtZWxlb25fQnVpbGRzL1BlcnNvbmFsX0J1aWxkcy9pbmRleC5waHA/cGVyc29uYWxidWlsZD1UcnVlJmRvd25sb2FkY29kZT0=') + str(downloadCode))
		check_Result = eval(Decode('cmUuZmluZGFsbChyJzxleGlzdHM+KC4qPyk8L2V4aXN0cz4nLHN0cihmaW5kX0J1aWxkKSk='))
		Result = ''
		for result in check_Result: Result = result
		if Result == 'True':
			password = dialog.input('Password', type=xbmcgui.INPUT_ALPHANUM)
			if password != '':
				build_Url = Decode('aHR0cDovL2NoYW1lbGVvbi54MTBob3N0LmNvbS9BZGRvbl9GaWxlcy9DaGFtZWxlb25fQnVpbGRzL1BlcnNvbmFsX0J1aWxkcy9pbmRleC5waHA/cGVyc29uYWxidWlsZD1UcnVlJmRvd25sb2FkY29kZT0=') + str(downloadCode) + '&password=' + str(password)
				verify_Password = open_URL(str(build_Url))
				if verify_Password != '':
					check_Password = eval(Decode('cmUuZmluZGFsbChyJzxwYXNzd29yZD4oLio/KTwvcGFzc3dvcmQ+JyxzdHIodmVyaWZ5X1Bhc3N3b3JkKSk='))
					PResult = ''
					for pass_Result in check_Password: PResult = pass_Result
					if PResult == 'True':
						build_Name = eval(Decode('cmUuZmluZGFsbChyJ2J1aWxkbmFtZT4oLio/KTwvYnVpbGRuYW1lPicsc3RyKHZlcmlmeV9QYXNzd29yZCkp'))
						BName = ''
						for bname in build_Name: BName = bname
						download_Link = eval(Decode('cmUuZmluZGFsbChyJzxkb3dubG9hZGxpbms+KC4qPyk8L2Rvd25sb2FkbGluaz4nLHN0cih2ZXJpZnlfUGFzc3dvcmQpKQ=='))
						Url = ''
						for url in download_Link: 
							Url = url + '?dl=1'
							WIZARD(BName,Url,BName+' Build Is Downloading Please Wait.',FANART)
					elif PResult == 'False':display_Message('Incorrect Password','The password entered was incorrect!')
					else: display_Message('Check Password Failed','Sorry we failed to check your,\npassword please try again later!')
				else: display_Message('Server Connection Error','Looks like the server didnt respond,\nplease try again later!')
			else: display_Message('Password Input Closed','See you again soon.')
		elif check_Result == 'False': display_Message('Incorrect Download Code','Download code provided was incorrect')
		else: display_Message('Build Doesn\'t Exist','We couldnt find the build that matches the\ndownload code provided!')
	else: display_Message('Download Code Input Closed','See you again soon.')
	
	AUTO_VIEW('500')
#-------------------------

def FamBuildUpdate():
	
	AUTO_VIEW('500')

#-------------------------

def FamBuildUpGrades():
	addDir('Zeus Addon & Repo',Decode('aHR0cHM6Ly9hcmNoaXZlLm9yZy9kb3dubG9hZC9jaHJpc19aRVVTL3pFVVMuemlw'),10,ART+'Zeus.png',FANART,'')
	addDir('i4ATV Addon & Repo',Decode('aHR0cHM6Ly9hcmNoaXZlLm9yZy9kb3dubG9hZC9jaHJpc19aRVVTL2k0QVRWLnppcA=='),10,ART+'i4ATV.png',FANART,'')
	AUTO_VIEW('500')

#-------------------------------------------------------
	
def SuperLight():
	addDir('Super Light 88MB',Decode('aHR0cHM6Ly93d3cuZHJvcGJveC5jb20vcy92YXpoMGhpMDE3OGdtemMvU3VwZXJMaWdodC56aXA/ZGw9MQ=='),10,ART+'L1DropBox.png',FANART,'')
	addDir('Build Fixes','',8,ART+'BuildFixes.png',FANART,'')
	addDir('Build Updates','',12,ART+'BuildUpdates.png',FANART,'')
	AUTO_VIEW('500')

#-------------------------

def SLBuildFixes():
	
	AUTO_VIEW('500')

#-------------------------

def SLBuildUpdate():
	
	AUTO_VIEW('500')

#-------------------------

def SLBuildUpGrades():
	
	AUTO_VIEW('500')

#-------------------------------------------------------

def Kids():
	addDir('Link 1 - DropBox',Decode('aHR0cHM6Ly93d3cuZHJvcGJveC5jb20vcy9kaHNvM2FheGFvZzhrcTIvS2lkc1YxLjEuemlwP2RsPTE='),10,ART+'L1DropBox.png',FANART,'')
	addDir('Link 2 - X10Host',Decode('aHR0cDovL2NoYW1lbGVvbi54MTBob3N0LmNvbS9CdWlsZHMvS2lkc1YxLjEuemlw'),10,ART+'L2X10Host.png',FANART,'')
	addDir('Link 3 - Archive.org',Decode('aHR0cHM6Ly9hcmNoaXZlLm9yZy9kb3dubG9hZC9LaWRzVjEuMS9LaWRzVjEuMS56aXA='),10,ART+'L3Archive.png',FANART,'')
	addDir('Build Fixes','',7,ART+'BuildFixes.png',FANART,'')
	addDir('Build Updates','',11,ART+'BuildUpdates.png',FANART,'')
	AUTO_VIEW('500')

#-------------------------

def KidBuildFixes():
	
	AUTO_VIEW('500')

#-------------------------

def KidBuildUpdate():
	
	AUTO_VIEW('500')

#-------------------------

def KidBuildUpGrades():
	
	AUTO_VIEW('500')

#-------------------------------------------------------

def open_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def WIZARD(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    #if description == '': description = name+" Downloadin Please Be Patient"
    #else: description = description
    dp.create("Downloading",description,'', 'Thank You')
    lib=os.path.join(path, name+'.zip')
    try:
        os.remove(lib)
    except:
        pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Just Installing - Not Long Now!")
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok("Force Close To Save", "All Done, we now need to force close to save the changes!")
    killxbmc()

def AUTO_VIEW(content = ''):
    if not content:
        return

    xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view') != 'true':
        return

    if content == 'addons':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting('addon_view'))
    else:
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting('default-view'))
        
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

def killxbmc():
    choice = xbmcgui.Dialog().yesno('Force Close Kodi', 'You are about to close Kodi', 'Would you like to continue?', nolabel='No, Cancel',yeslabel='Yes, Close')
    if choice == 0:
        return
    elif choice == 1:
        pass
    myplatform = platform()
    print "Platform: " + str(myplatform)
    if myplatform == 'osx': # OSX
        print "############   try osx force close  #################"
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'linux': #Linux
        print "############   try linux force close  #################"
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'android': # Android  
        print "############   try android force close  #################"
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass        
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "Your system has been detected as Android, you ", "[COLOR=yellow][B]MUST[/COLOR][/B] force close XBMC/Kodi. [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Pulling the power cable is the simplest method to force close.")
    elif myplatform == 'windows': # Windows
        print "############   try windows force close  #################"
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","Your platform could not be detected so just pull the power cable.")    

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')

def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addLink(name,url,mode,iconimage,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def display_Message(heading,body):
	dialog = xbmcgui.Dialog()
	dialog.ok(heading, body)
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)

		
if mode   == None               : INDEX()
elif mode == 2        	  		: FAMILY()
elif mode == 3					: SuperLight()
elif mode == 4					: FamBuildFixes()
elif mode == 6              	: Kids()
elif mode == 7					: KidBuildFixes()
elif mode == 8					: SLBuildFixes()
elif mode == 9					: FamBuildUpdate()
elif mode == 10			        : WIZARD(name,url,description)
elif mode == 11					: KidBuildUpdate()
elif mode == 12					: SLBuildUpdate()
elif mode == 13					: FamBuildUpGrades()
elif mode == 14					: KidBuildUpGrades()
elif mode == 15					: SLBuildUpGrades()
elif mode == 16					: personal_Builds()

#-------------------------------------------------------
xbmcplugin.endOfDirectory(int(sys.argv[1]))