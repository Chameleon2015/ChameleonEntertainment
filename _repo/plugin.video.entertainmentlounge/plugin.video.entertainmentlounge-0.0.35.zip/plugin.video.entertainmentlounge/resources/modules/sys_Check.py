import os.path, binascii, base64, re, urllib2, xbmc, modules, xbmcgui, shutil
path_Addon = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.entertainmentlounge'))
path_Repo = xbmc.translatePath(os.path.join('special://home/addons/repository.ChameleonEntertainment'))

def system_Check(string, sys_Password):
	file_Check = os.path
	Decode = base64.decodestring
	if file_Check.exists(string) == True:
		PATH1 = xbmc.translatePath(os.path.join('special://home/userdata/Database/'))
		FILE1 = 'syscheck1.ini'
		if file_Check.exists(PATH1) & file_Check.isfile(PATH1+FILE1) == True:
			open_File = open(PATH1+FILE1, 'r',0)
			check_File = open_File.read()
			open_File.close()
			get_Data = text_from_bits(check_File)
			data1 = re.findall(r'<path>(.*?)</path>',str(get_Data))
			data2 = re.findall(r'<file>(.*?)</file>',str(get_Data))
			for data_One in data1: check1 = data_One
			for data_Two in data2: check2 = data_Two
			clean_DIR = os.path.abspath(eval(check1))
			if file_Check.exists(eval(check1)) ==  True & file_Check.isfile(clean_DIR+'\\'+check2) == True:
				open_File = open(clean_DIR+'\\'+check2,'r+',0)
				check_File = open_File.read()
				open_File.close()
				get_Data = text_from_bits(check_File)
				auth = []
				data3 = re.findall(r'<path>(.*?)</path>',str(get_Data))
				data4 = re.findall(r'<file>(.*?)</file>',str(get_Data))
				for data_One in data3: check3 = data_One
				for data_Two in data4: check4 = data_Two
				clean_DIR = os.path.abspath(eval(check3))
				if file_Check.exists(eval(check3)) ==  True & file_Check.isfile(clean_DIR+'\\'+check4) == True:
					open_File = open(clean_DIR+'\\'+check4, 'r',0)
					check_File = open_File.read()
					open_File.close()
					get_Data = text_from_bits(check_File)
					data5 = re.findall(r'<path>(.*?)</path>',str(get_Data))
					data6 = re.findall(r'<file>(.*?)</file>',str(get_Data))
					data7 = re.findall(r'<passcode>(.*?)</passcode>',str(get_Data))
					for data_One in data5: check5 = data_One
					for data_Two in data6: check6 = data_Two
					for data_Three in data7: auth.append(data_Three)
					clean_DIR = os.path.abspath(eval(check5))
					if file_Check.exists(eval(check5)) ==  True & file_Check.isfile(clean_DIR+'\\'+check6) == True:
						open_File = open(clean_DIR+'\\'+check6, 'r',0)
						check_File = open_File.read()
						open_File.close()
						get_Data = text_from_bits(check_File)
						data7 = re.findall(Decode('cic8YXV0aHVybD4oLis/KTwvYXV0aHVybD4n'),get_Data)
						for data_One in data7: auth.append(data_One);
						auth_URL = Decode('aHR0cDovL2VudGVydGFpbm1lbnRsaXN0cy54MTBob3N0LmNvbS9hdXRob3Jpc2F0aW9uL3NlY3VyaXR5LnBocD8=')+'passcode='+auth[0]+'&password='+sys_Password
						finalise_Sum = open_URL(auth_URL)
						auth_Result = re.compile(Decode('PGgxPiguKz8pPC9oMT48aDI+KC4rPyk8L2gyPjxoMz4oLis/KTwvaDM+PGg0PiguKz8pPC9oND4='),re.DOTALL).findall(finalise_Sum)
						for msg, sum, follow, status in auth_Result: 
							if follow == 'True':
								test_Sum = int(sum) / 5.55
								if str(test_Sum) == Decode('MTc5LjI3OTI3OTI3OQ=='):
									if status == 'online':
										return True
									elif status == 'offline':
										return False
									else: pass
								else: clean_UP()
							else: clean_UP()
					else: clean_UP()
				else: clean_UP()
			else: clean_UP()
		else: clean_UP()
	else: clean_UP()


def clean_UP():
	dialog = xbmcgui.Dialog()
	dialog.ok("Authorisation Failed", "This Add-On is for private use only sorry!")
	shutil.rmtree(path_Addon, ignore_errors=True)
	shutil.rmtree(path_Repo, ignore_errors=True)
	
def down_Maintenance(sys_Password):
	auth_URL = 'http://entertainmentlists.x10host.com/Maintenance.php?'+'password='+sys_Password
	status = open_URL(auth_URL)
	Decode = base64.decodestring
	status_Result = eval(Decode("cmUuY29tcGlsZShEZWNvZGUoJ1BHZzBQaWd1S3o4cFBDOW9ORDQ9JykscmUuRE9UQUxMKS5maW5kYWxsKHN0YXR1cyk="))
	for status in status_Result: 
		if status == 'online':
			return True
		elif status == 'offline':
			return False
		else: pass

def maintenance_Popup():
	dialog = xbmcgui.Dialog()
	dialog.ok("Routine Maintenance", "Currently Down For Routine Maintenance.\nCheck Back Soon.")

def no_Sys_Password():
	dialog = xbmcgui.Dialog()
	dialog.ok("System Password Not Found", "Sorry We Couldnt Detect A Password\nPassword Can Be Found In The Group")

def text_to_bits(text, encoding='utf-8', errors='surrogatepass'):
    bits = bin(int(binascii.hexlify(text.encode(encoding, errors)), 16))[2:]
    return bits.zfill(8 * ((len(bits) + 7) // 8))

def text_from_bits(bits, encoding='utf-8', errors='surrogatepass'):
    n = int(bits, 2)
    return int2bytes(n).decode(encoding, errors)

def int2bytes(i):
    hex_string = '%x' % i
    n = len(hex_string)
    return binascii.unhexlify(hex_string.zfill(n + (n & 1)))

def open_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link